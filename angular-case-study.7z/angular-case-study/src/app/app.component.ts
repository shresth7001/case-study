import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap} from '@angular/router';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-case-study';
constructor(protected  router:Router){}
  onClickRoute1(){
    this.router.navigate(['route1']);
    }
  onClickRoute2(){
    this.router.navigate(['route2']);
  }
  onClickRoute3(){
    this.router.navigate(['route3']);
  }
  onClickRoute4(){
    this.router.navigate(['route4']);
  }
  onClickRoute5(){
    this.router.navigate(['route5']);

  }
  onClickRoute6(){
    this.router.navigate(['route6']);
  }
}
