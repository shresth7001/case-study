import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RouteFiveComponent } from './route-component/route-five/route-five.component';
import { RouteFourComponent } from './route-component/route-four/route-four.component';
import { DisplayCountNew } from './route-component/route-four/timer/display-count-new/display-count.component';
import { DisplayTimerNew } from './route-component/route-four/timer/display-timer-new/display-timer-new.component';
import { TimerLimitComponentNew } from './route-component/route-four/timer/timer-limit/timer-limit.component';
import { TimerService } from './route-component/route-four/timer/timer.service';
import { TimeStampNew } from './route-component/route-four/timer/timestamp/timestamp.component';
import { RouteOneComponent } from './route-component/route-one/route-one.component';
import { RouteThreeComponent } from './route-component/route-three/route-three.component';
import { DisplayCount } from './route-component/route-three/timer/display-count/display-count.component';
import { DisplayTimer } from './route-component/route-three/timer/display-timer/display-timercomponent';
import { TimerLimitComponent } from './route-component/route-three/timer/timer-limit/timer-limit.component';
import { TimeStamp } from './route-component/route-three/timer/timestamp/timestamp.component';
import { RouteTwoComponent } from './route-component/route-two/route-two.component';

@NgModule({
  declarations: [
    AppComponent,
    RouteOneComponent,
    RouteTwoComponent,
    RouteThreeComponent,
    RouteFourComponent,
    RouteFiveComponent,
    DisplayTimer,
    DisplayCount,
    TimerLimitComponent,
    TimeStamp,
    DisplayCountNew,
    TimeStampNew,
    TimerLimitComponentNew,
    DisplayTimerNew
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [TimerService],
  bootstrap: [AppComponent]
})
export class AppModule { }
