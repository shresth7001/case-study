import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RouteFiveComponent } from './route-component/route-five/route-five.component';
import { RouteFourComponent } from './route-component/route-four/route-four.component';
import { RouteOneComponent } from './route-component/route-one/route-one.component';
import { RouteSixComponent } from './route-component/route-six/route-six.component';
import { RouteThreeComponent } from './route-component/route-three/route-three.component';
import { RouteTwoComponent } from './route-component/route-two/route-two.component';

const routes: Routes = [ { path: 'route1', component: RouteOneComponent  },
{ path: 'route2', component: RouteTwoComponent  },
{ path: 'route3', component: RouteThreeComponent  },
{ path: 'route4', component: RouteFourComponent  },
{ path: 'route5', component: RouteFiveComponent  },
{ path: 'route6', component: RouteSixComponent  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
