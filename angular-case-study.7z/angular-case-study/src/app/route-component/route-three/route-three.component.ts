import { Component } from '@angular/core';

@Component({
  selector: 'route-three',
  templateUrl: './route-three.component.html',
  styleUrls: ['./route-three.component.css']
})
export class RouteThreeComponent {

  timerVal : any;
  startCount = 0;
  pauseCount = 0;
  counterVal : any;
  paused:any;
  started:any;
  reset: any;
  getTimerLimit(value:any) {
    this.timerVal = value;
  }
  getStartCount(value:any){
this.startCount = value;
  }
  getPauseCount(value:any){
    console.log(value);
    
    this.pauseCount = value;

  }
  getCounterVal(value:any){
    this.counterVal = value;
  }
  isPaused(value:any){
    this.paused = value;
  }
  isStarted(value:any){
    this.started = value;
  }
  isReset(value:any){
    this.reset = value;
  }
}
