import { Component, Input } from '@angular/core';

@Component({
  selector: 'time-stamp',
  templateUrl: './timestamp.component.html',
  styleUrls: ['./timestamp.component.css']
})
export class TimeStamp {
@Input() isPaused : any;
@Input() isStarted : any;
@Input() isreset: any;
timeStamp= [] as any;
ngOnChanges(){
  if(this.isPaused){
    this.timeStamp.push('Paused at ' + new Date().toLocaleString());
  } if(this.isStarted){
    this.timeStamp.push('Started at ' + new Date().toLocaleString());
  }
  if(this.isreset){
    this.timeStamp = [];
  }
}

}
