import { Component, Input } from '@angular/core';

@Component({
  selector: 'display-count',
  templateUrl: './display-count.component.html',
  styleUrls: ['./display-count.component.css']
})
export class DisplayCount {
  @Input() startCount: any; 
  @Input() pauseCount: any; 



}
