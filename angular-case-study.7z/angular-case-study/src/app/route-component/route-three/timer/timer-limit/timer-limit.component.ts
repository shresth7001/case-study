import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'timer-limit',
  templateUrl: './timer-limit.component.html',
  styleUrls: ['./timer-limit.component.css']
})
export class TimerLimitComponent {
  timer: any;
@Output() timerLimitVal = new EventEmitter();
@Output() startCount = new EventEmitter();
@Output() pauseCount = new EventEmitter();
@Input() counterVal: any;
@Output() isPaused = new EventEmitter();
@Output() isStarted = new EventEmitter();
@Output() isReset = new EventEmitter();
counter = 0;
started = 0;
paused = 0;
pausedValues = [] as any;
  onClickStartPause(){
    if(this.timer){
      if(this.counter === 0){
        this.timerLimitVal.emit(this.timer);
      }
      if(this.counter % 2 === 0){
        this.started++;
        this.counter++;
        this.startCount.emit(this.started);
        this.isPaused.emit(false);
        this.isStarted.emit(true);
        this.isReset.emit(false);
  
      } else{
        this.paused++;
        this.counter++;
        this.pauseCount.emit(this.paused);
        this.isPaused.emit(true);
        this.isStarted.emit(false);
        if(this.counterVal){this.pausedValues.push(this.counterVal)};
        this.isReset.emit(false);
      }
    }

  }
  OnClickReset(){
    this.timer = '';
    this.counter = 0
    this.timerLimitVal.emit(this.timer);
    this.started = 0;
    this.paused = 0;
    this.startCount.emit(this.started);
    this.pauseCount.emit(this.paused);
    this.isStarted.emit(false);
    this.isPaused.emit(false);
    this.isReset.emit(true);
    this.pausedValues = [];
  }
}
