import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';

@Component({
  selector: 'display-timer',
  templateUrl: './display-timer.component.html',
  styleUrls: ['./display-timer.component.css']
})
export class DisplayTimer implements OnChanges,OnInit {
  @Input() timerVal: any;
  @Output() counterVal = new EventEmitter();
  @Input() isPaused:any;
  @Input() isreset: any;
  counter = 0;
  firstTime = true;
  ngOnChanges(){
    
    if(this.firstTime && this.timerVal){
    this.counter = this.timerVal;
    this.firstTime = false;
  }
  if(this.isreset){
    this.counter = 0;
    this.firstTime = true;
  }
}
  ngOnInit() {
    setInterval(() => {
      if(this.counter>0 && !this.isPaused){
        this.counter--;
      }
      this.counterVal.emit(this.counter);
    }, 1000);
  }
}
