import { Component } from '@angular/core';

@Component({
  selector: 'route-one',
  templateUrl: './route-one.component.html',
  styleUrls: ['./route-one.component.css']
})
export class RouteOneComponent {




}
