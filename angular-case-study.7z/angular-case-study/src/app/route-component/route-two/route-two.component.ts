import { Component, OnInit } from '@angular/core';
import data from '../../products.json';
@Component({
  selector: 'route-two',
  templateUrl: './route-two.component.html',
  styleUrls: ['./route-two.component.css']
})
export class RouteTwoComponent implements OnInit {
  pdtData : Products[] = data;
  display = 1;
  constructor(){
  }
 ngOnInit(){
console.log(this.pdtData);
 }
 sort(event: any) {
  switch (event.target.value) {
    case 'Low':
      {
        this.pdtData = this.pdtData.sort((low, high) => low.price - high.price);
        break;
      }

    case 'High':
      {
        this.pdtData = this.pdtData.sort((low, high) => high.price - low.price);
        break;
      }

    default: {
      this.pdtData = this.pdtData.sort((low, high) => low.price - high.price);
      break;
    }

  }
  return this.pdtData;

}
changeDisplay(val:any){
this.display = val;
}
}

interface Products{
  name: string;
  imageURL: string;
  description: string;
  price: number;
}