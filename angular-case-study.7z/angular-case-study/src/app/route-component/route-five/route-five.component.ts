import { Component } from '@angular/core';
import data from '../../student.json';
@Component({
  selector: 'route-five',
  templateUrl: './route-five.component.html',
  styleUrls: ['./route-five.component.css'],
})
export class RouteFiveComponent {
  isDesc: boolean = false;
  nameSortOrder = 1;
  classSortOrder = 1;
  sectionSortOrder = 1;
  sub1SortOrder = 1;
  sub2SortOrder = 1;
  sub3SortOrder = 1;
  students: Student[] = data;

  constructor() {}
  sort(event: any) {
    switch (event.target.innerText) {
      case 'Name': {
        this.students = this.students.sort(
          (low, high) =>
            low.name
              .toLocaleLowerCase()
              .localeCompare(high.name.toLocaleLowerCase()) * this.nameSortOrder
        );
        if (this.nameSortOrder === 1) {
          this.nameSortOrder = -1;
        } else {
          this.nameSortOrder = 1;
        }
        break;
      }

      case 'Class': {
        this.students = this.students.sort(
          (low, high) => (low.class - high.class) * this.classSortOrder
        );
        if (this.classSortOrder === 1) {
          this.classSortOrder = -1;
        } else {
          this.classSortOrder = 1;
        }
        break;
      }
      case 'Section': {
        this.students = this.students.sort(
          (low, high) =>
            low.section
              .toLocaleLowerCase()
              .localeCompare(high.section.toLocaleLowerCase()) *
            this.sectionSortOrder
        );

        if (this.sectionSortOrder === 1) {
          this.sectionSortOrder = -1;
        } else {
          this.sectionSortOrder = 1;
        }
        break;
      }
      case 'Sub1': {
        this.students = this.students.sort(
          (low, high) => (low.sub1 - high.sub1) * this.sub1SortOrder
        );
        if (this.sub1SortOrder === 1) {
          this.sub1SortOrder = -1;
        } else {
          this.sub1SortOrder = 1;
        }
        break;
      }
      case 'Sub2': {
        this.students = this.students.sort(
          (low, high) => (low.sub2 - high.sub2) * this.sub2SortOrder
        );
        if (this.sub2SortOrder === 1) {
          this.sub2SortOrder = -1;
        } else {
          this.sub2SortOrder = 1;
        }
        break;
      }
      case 'Sub3': {
        this.students = this.students.sort(
          (low, high) => (low.sub3 - high.sub3) * this.sub3SortOrder
        );
        if (this.sub3SortOrder === 1) {
          this.sub3SortOrder = -1;
        } else {
          this.sub3SortOrder = 1;
        }
        break;
      }
    }
    return this.students;
  }
}
interface Student {
  name: string;
  class: number;
  section: string;
  sub1: number;
  sub2: number;
  sub3: number;
}
