import { Component } from '@angular/core';

@Component({
  selector: 'route-four',
  templateUrl: './route-four.component.html',
  styleUrls: ['./route-four.component.css']
})
export class RouteFourComponent {
}
