import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { TimerService } from '../timer.service';

@Component({
  selector: 'display-count-new',
  templateUrl: './display-count.component.html',
  styleUrls: ['./display-count.component.css']
})
export class DisplayCountNew implements OnInit  {
  startCount = 0; 
  pauseCount = 0; 
  constructor(protected timerService: TimerService){}

ngOnInit(){
  this.timerService.startCount.subscribe((value)=>{
    this.startCount = value;
  })
  this.timerService.pauseCount.subscribe((value)=>{
    this.pauseCount = value;
  })
}


}
