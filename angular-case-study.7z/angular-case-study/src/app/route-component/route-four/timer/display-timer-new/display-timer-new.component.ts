import { AfterViewInit, Component, OnInit } from '@angular/core';
import { TimerService } from '../timer.service';

@Component({
  selector: 'display-timer-new',
  templateUrl: './display-timer-new.component.html',
  styleUrls: ['./display-timer-new.component.css'],
})
export class DisplayTimerNew implements OnInit {
  counter: any;
  firstTime = true;
  constructor(protected timerService: TimerService) {}
  paused = false;

  ngOnInit() {
    this.timerService.timerLimitVal.subscribe((value) => {
      this.counter = value;
      this.firstTime = false;
    });
    this.timerService.isReset.subscribe((value) => {
      if (value) {
        this.counter = 0;
        this.firstTime = true;
      }
    });
    this.timerService.isPaused.subscribe((value) => {
        this.paused = value;
    });

    setInterval(() => {
      if (this.counter > 0 && !this.paused) {
        this.counter--;
      }
      this.timerService.setCounterVal(this.counter);
    }, 1000);
  }
}
