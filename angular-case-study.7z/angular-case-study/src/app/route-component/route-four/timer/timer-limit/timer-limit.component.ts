import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { TimerService } from '../timer.service';

@Component({
  selector: 'timer-limit-new',
  templateUrl: './timer-limit.component.html',
  styleUrls: ['./timer-limit.component.css']
})
export class TimerLimitComponentNew {
  timer: any;
  counterval: any;
constructor(protected timerService: TimerService){}
counter = 0;
started = 0;
paused = 0;
pausedValues = [] as any;
  onClickStartPause(){
    if(this.timer){
      if(this.counter === 0){
        this.timerService.timerLimitVal.next(this.timer);
      }
      if(this.counter % 2 === 0){
        this.started++;
        this.counter++;
        this.timerService.startCount.next(this.started);
        this.timerService.isPaused.next(false);
        this.timerService.isStarted.next(true);
        this.timerService.isReset.next(false);
  
      } else{
        this.paused++;
        this.counter++;
        this.timerService.pauseCount.next(this.paused);
        this.timerService.isPaused.next(true);
        this.timerService.isStarted.next(false);
        this.timerService.isReset.next(false);
        this.counterval = this.timerService.getCounterVal();
       if(this.counterval){this.pausedValues.push(this.counterval)};
      }
    }

  }
  OnClickReset(){
    this.timer = '';
    this.counter = 0;
    this.started = 0;
    this.paused = 0;
    this.timerService.timerLimitVal.next(this.timer);
    this.timerService.startCount.next(this.started);
    this.timerService.pauseCount.next(this.paused);
    this.timerService.isPaused.next(false);
    this.timerService.isStarted.next(false);
    this.timerService.isReset.next(true);
    this.pausedValues = [];
  }
}
