import { Component, Input } from '@angular/core';
import { TimerService } from '../timer.service';

@Component({
  selector: 'time-stamp-new',
  templateUrl: './timestamp.component.html',
  styleUrls: ['./timestamp.component.css']
})
export class TimeStampNew {
timeStamp= [] as any;
constructor(protected timerService: TimerService){}
ngOnInit(){
  this.timerService.isPaused.subscribe((val)=>{
if(val){
  this.timeStamp.push('Paused at ' + new Date().toLocaleString());
}
  })
  this.timerService.isStarted.subscribe((val)=>{
    if(val){
      this.timeStamp.push('Started at ' + new Date().toLocaleString());
    }
      })
      this.timerService.isReset.subscribe((val)=>{
        if(val){
          this.timeStamp = [];
        }
          })
}

}
