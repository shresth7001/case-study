import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class TimerService {
  timerLimitVal = new BehaviorSubject(0);
  startCount = new BehaviorSubject(0);
  pauseCount = new BehaviorSubject(0);
  isPaused = new BehaviorSubject(false);
  isStarted =  new BehaviorSubject(false);
 isReset =  new BehaviorSubject(false);
 counterVal: any;


setCounterVal(data:any){
  this.counterVal = data;
}
getCounterVal(){
  return this.counterVal;
}
constructor() { }

}