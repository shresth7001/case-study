import { Component, ElementRef, HostListener, Renderer2, ViewChild } from '@angular/core';

@Component({
  selector: 'route-six',
  templateUrl: './route-six.component.html',
  styleUrls: ['./route-six.component.css']
})
export class RouteSixComponent {
  @ViewChild('myDiv') myDiv: ElementRef | undefined;
  ct = 15;
  buttonNm: string | undefined;
  container = document.querySelector('.container');
  nativeElement: any;
  constructor(private renderer: Renderer2,private element:ElementRef) {
    }
insertDiv(){
if(this.myDiv){
  for (let index = 0; index <2; index++) {
    this.buttonNm = 'Button ' + this.ct;
    this.nativeElement = this.element.nativeElement;
    const div = this.renderer.createElement('div');
    const button= this.renderer.createElement('button');
    const text = this.renderer.createText(`${this.buttonNm}`);
    this.renderer.appendChild(button, text);
    this.renderer.appendChild(div, button);
    this.renderer.addClass(div,'button-div');
    this.renderer.setProperty(button,'value',`${this.buttonNm}`)
    this.renderer.addClass(div,'number');
    this.renderer.insertBefore(this.element.nativeElement, div, this.element.nativeElement.lastSibling);
  this.ct++;
  }
}

}
    @HostListener('window:scroll', ['$event']) onScrollEvent($event : any){
      this.insertDiv();
  }
  @HostListener('window:click', ['$event']) onClickEvent($event : any){
alert($event.srcElement.value.split(' ')[0]+' in div '+$event.srcElement.value.split(' ')[1]+' is clicked');
}
}
